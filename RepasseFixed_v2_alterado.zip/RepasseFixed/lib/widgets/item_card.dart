import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/item.dart';
import '../screens/item_detail_screen.dart';

class ItemCard extends StatefulWidget {
  final Item item;
  final int currentUserId;
  final VoidCallback? onSave;

  const ItemCard({
    super.key,
    required this.item,
    required this.currentUserId,
    this.onSave,
  });

  @override
  State<ItemCard> createState() => _ItemCardState();
}

class _ItemCardState extends State<ItemCard> {
  bool _saved = false;
  bool _toggling = false;

  @override
  void initState() {
    super.initState();
    _checkSaved();
  }

  Future<void> _checkSaved() async {
    if (widget.item.id == null) return;
    final s = await DatabaseHelper.instance
        .isItemSaved(widget.currentUserId, widget.item.id!);
    if (mounted) setState(() => _saved = s);
  }

  Future<void> _toggleSave() async {
    if (_toggling || widget.item.id == null) return;
    _toggling = true;
    setState(() => _saved = !_saved);
    await DatabaseHelper.instance
        .toggleSaveItem(widget.currentUserId, widget.item.id!);
    _toggling = false;
    widget.onSave?.call();
  }

  Color get _typeColor => widget.item.type == 'doacao'
      ? const Color(0xFF00A86B)
      : const Color(0xFF00BCD4);

  bool get _isNetworkImage {
    final p = widget.item.photoPath;
    return p != null && (p.startsWith('http://') || p.startsWith('https://'));
  }

  Widget _buildImage() {
    final path = widget.item.photoPath;
    if (path == null || path.isEmpty) return _placeholder;

    if (_isNetworkImage) {
      return CachedNetworkImage(
        imageUrl: path,
        fit: BoxFit.cover,
        memCacheWidth: 400,
        fadeInDuration: const Duration(milliseconds: 200),
        placeholder: (_, __) => const ColoredBox(
          color: Color(0xFFF0F0F0),
          child: Center(
            child: SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 1.5),
            ),
          ),
        ),
        errorWidget: (_, __, ___) => _placeholder,
      );
    }

    return Image.file(
      File(path),
      fit: BoxFit.cover,
      cacheWidth: 400,
      errorBuilder: (_, __, ___) => _placeholder,
    );
  }

  static const Widget _placeholder = ColoredBox(
    color: Color(0xFFEEEEEE),
    child: Center(
      child: Icon(Icons.image_outlined, size: 40, color: Color(0xFFBDBDBD)),
    ),
  );

  Widget _typeBadge() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: _typeColor,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              widget.item.type == 'doacao'
                  ? Icons.card_giftcard
                  : Icons.repeat,
              color: Colors.white,
              size: 12,
            ),
            const SizedBox(width: 3),
            Text(
              widget.item.type == 'doacao' ? 'Doação' : 'Troca',
              style: const TextStyle(color: Colors.white, fontSize: 11),
            ),
          ],
        ),
      );

  void _openDetails() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ItemDetailScreen(item: widget.item),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _openDetails,
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  RepaintBoundary(child: _buildImage()),
                  Positioned(top: 8, left: 8, child: _typeBadge()),
                  Positioned(
                    top: 4,
                    right: 4,
                    child: GestureDetector(
                      onTap: _toggleSave,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _saved ? Icons.favorite : Icons.favorite_border,
                          color: _saved ? Colors.red : Colors.grey,
                          size: 18,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.item.title,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 13),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.location_on,
                          size: 12, color: Colors.grey),
                      const SizedBox(width: 2),
                      Text(
                        '${widget.item.distanceKm.toStringAsFixed(1)} km',
                        style:
                            const TextStyle(fontSize: 11, color: Colors.grey),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
