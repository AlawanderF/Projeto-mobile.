import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/user.dart';
import '../models/item.dart';
import '../models/message.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  // FIX 3: Completer garante que _initDB() seja chamado uma única vez,
  // mesmo se múltiplos awaits simultâneos chegarem antes da inicialização terminar.
  static Completer<Database>? _initCompleter;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    if (_initCompleter != null) return _initCompleter!.future;

    _initCompleter = Completer<Database>();
    try {
      _database = await _initDB('repassa.db');
      _initCompleter!.complete(_database!);
    } catch (e) {
      _initCompleter!.completeError(e);
      _initCompleter = null; // permite nova tentativa em caso de erro
      rethrow;
    }
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(
      path,
      version: 3,
      onCreate: _createDB,
      onUpgrade: _upgradeDB,
    );
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        bio TEXT,
        photoPath TEXT,
        rating REAL DEFAULT 0.0,
        totalRatings INTEGER DEFAULT 0,
        sharedCount INTEGER DEFAULT 0,
        savedCount INTEGER DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        category TEXT NOT NULL,
        type TEXT NOT NULL,
        photoPath TEXT,
        status TEXT DEFAULT 'ativo',
        latitude REAL,
        longitude REAL,
        locationName TEXT,
        distanceKm REAL DEFAULT 0.0,
        condition TEXT DEFAULT 'semi_novo',
        acquiredAt TEXT,
        estimatedValue REAL,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (userId) REFERENCES users (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE saved_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId INTEGER NOT NULL,
        itemId INTEGER NOT NULL,
        FOREIGN KEY (userId) REFERENCES users (id),
        FOREIGN KEY (itemId) REFERENCES items (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId1 INTEGER NOT NULL,
        userId2 INTEGER NOT NULL,
        lastMessage TEXT,
        lastMessageAt TEXT,
        unreadCount INTEGER DEFAULT 0,
        itemId INTEGER,
        itemTitle TEXT,
        FOREIGN KEY (userId1) REFERENCES users (id),
        FOREIGN KEY (userId2) REFERENCES users (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        conversationId INTEGER NOT NULL,
        senderId INTEGER NOT NULL,
        content TEXT NOT NULL,
        sentAt TEXT NOT NULL,
        isRead INTEGER DEFAULT 0,
        FOREIGN KEY (conversationId) REFERENCES conversations (id)
      )
    ''');

    // FIX — MELHORIA: Índices para acelerar as queries mais frequentes.
    await db.execute('CREATE INDEX idx_items_userId ON items(userId)');
    await db.execute('CREATE INDEX idx_items_status ON items(status)');
    await db.execute('CREATE INDEX idx_saved_userId ON saved_items(userId)');
    await db.execute('CREATE INDEX idx_saved_itemId ON saved_items(itemId)');
    // Índice composto para isItemSaved() que filtra pelos dois campos juntos:
    await db.execute(
        'CREATE UNIQUE INDEX idx_saved_unique ON saved_items(userId, itemId)');
    await db
        .execute('CREATE INDEX idx_messages_conv ON messages(conversationId)');

    await _seedDemoData(db);
  }

  Future<void> _upgradeDB(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute("ALTER TABLE items ADD COLUMN condition TEXT DEFAULT 'semi_novo'");
      await db.execute('ALTER TABLE items ADD COLUMN acquiredAt TEXT');
      await db.execute('ALTER TABLE items ADD COLUMN estimatedValue REAL');
    }
    if (oldVersion < 3) {
      await _applyDemoProductDetails(db);
      await _seedDemoMessages(db);
    }
  }

  Future<void> _applyDemoProductDetails(Database db) async {
    final now = DateTime.now();
    final updates = [
      {'title': 'Jaqueta de couro vintage', 'condition': 'usado', 'days': 180, 'value': 370.0},
      {'title': 'Poltrona retrô azul', 'condition': 'semi_novo', 'days': 60, 'value': 990.0},
      {'title': 'Livros de ficção', 'condition': 'usado', 'days': 300, 'value': 80.0},
      {'title': 'Bicicleta mountain bike', 'condition': 'usado', 'days': 240, 'value': 1000.0},
      {'title': 'Kit de utensílios de cozinha', 'condition': 'semi_novo', 'days': 25, 'value': 90.0},
      {'title': 'Fones de ouvido bluetooth', 'condition': 'semi_novo', 'days': 45, 'value': 250.0},
    ];

    for (final item in updates) {
      await db.update(
        'items',
        {
          'condition': item['condition'],
          'acquiredAt': now.subtract(Duration(days: item['days'] as int)).toIso8601String(),
          'estimatedValue': item['value'],
        },
        where: 'title = ?',
        whereArgs: [item['title']],
      );
    }
  }

  Future<void> _seedDemoMessages(Database db) async {
    final count = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM messages')) ?? 0;
    if (count > 0) return;

    Future<void> add(int conversationId, int senderId, String content, Duration ago) async {
      await db.insert('messages', {
        'conversationId': conversationId,
        'senderId': senderId,
        'content': content,
        'sentAt': DateTime.now().subtract(ago).toIso8601String(),
        'isRead': 1,
      });
    }

    await add(1, 2, 'Oi! Ainda tem a jaqueta disponível?', const Duration(hours: 4, minutes: 20));
    await add(1, 1, 'Tenho sim. Ela está usada, mas muito conservada.', const Duration(hours: 4, minutes: 12));
    await add(1, 2, 'Você aceitaria reservar até amanhã?', const Duration(hours: 4, minutes: 5));
    await add(1, 1, 'Reservo sim. Pode buscar no fim da tarde.', const Duration(hours: 3, minutes: 58));

    await add(2, 1, 'Oi, tenho interesse nesses livros.', const Duration(hours: 2, minutes: 30));
    await add(2, 2, 'Legal! Você pensou em troca ou volta em dinheiro?', const Duration(hours: 2, minutes: 18));
    await add(2, 1, 'Posso trocar por uma cadeira, te interessa?', const Duration(hours: 2));

    await add(3, 3, 'Oi, gostei da jaqueta. Ela serve M mesmo?', const Duration(days: 1, hours: 2));
    await add(3, 1, 'Serve sim, o corte é regular.', const Duration(days: 1, hours: 1));
    await add(3, 3, 'Obrigada! Vou buscar amanhã 🙂', const Duration(days: 1));
  }

  Future<void> _seedDemoData(Database db) async {
    // FIX 2: Senhas armazenadas como hash SHA-256.
    final hash = User.hashPassword;

    await db.insert('users', {
      'name': 'João Santos',
      'email': 'joao@demo.com',
      'password': hash('123456'),
      'bio':
          'Apaixonado por sustentabilidade 🌱 Compartilhando itens para reduzir o desperdício!',
      'rating': 4.9,
      'totalRatings': 47,
      'sharedCount': 23,
      'savedCount': 89,
    });

    await db.insert('users', {
      'name': 'Maria Silva',
      'email': 'maria@demo.com',
      'password': hash('123456'),
      'bio': 'Amo reciclar e reutilizar!',
      'rating': 4.7,
      'totalRatings': 32,
      'sharedCount': 15,
      'savedCount': 60,
    });

    await db.insert('users', {
      'name': 'Ana Costa',
      'email': 'ana@demo.com',
      'password': hash('123456'),
      'bio': 'Menos é mais!',
      'rating': 4.8,
      'totalRatings': 20,
      'sharedCount': 10,
      'savedCount': 40,
    });

    final now = DateTime.now().toIso8601String();

    await db.insert('items', {
      'userId': 1,
      'title': 'Jaqueta de couro vintage',
      'description': 'Jaqueta de couro marrom, tamanho M, em ótimo estado.',
      'category': 'Roupas',
      'type': 'doacao',
      'photoPath': 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&q=80',
      'status': 'ativo',
      'locationName': 'São Paulo, SP',
      'distanceKm': 1.2,
      'condition': 'usado',
      'acquiredAt': DateTime.now().subtract(const Duration(days: 180)).toIso8601String(),
      'estimatedValue': 370.0,
      'createdAt': now,
    });

    await db.insert('items', {
      'userId': 2,
      'title': 'Poltrona retrô azul',
      'description': 'Poltrona vintage azul, muito confortável.',
      'category': 'Móveis',
      'type': 'troca',
      'photoPath': 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?w=400&q=80',
      'status': 'ativo',
      'locationName': 'São Paulo, SP',
      'distanceKm': 2.5,
      'condition': 'semi_novo',
      'acquiredAt': DateTime.now().subtract(const Duration(days: 60)).toIso8601String(),
      'estimatedValue': 990.0,
      'createdAt': now,
    });

    await db.insert('items', {
      'userId': 1,
      'title': 'Livros de ficção',
      'description': 'Coleção de livros de ficção científica.',
      'category': 'Livros',
      'type': 'troca',
      'photoPath': 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&q=80',
      'status': 'ativo',
      'locationName': 'São Paulo, SP',
      'distanceKm': 0.8,
      'condition': 'usado',
      'acquiredAt': DateTime.now().subtract(const Duration(days: 300)).toIso8601String(),
      'estimatedValue': 80.0,
      'createdAt': now,
    });

    await db.insert('items', {
      'userId': 3,
      'title': 'Bicicleta mountain bike',
      'description': 'MTB aro 29, 21 marchas, usada.',
      'category': 'Esportes',
      'type': 'troca',
      'photoPath': 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80',
      'status': 'ativo',
      'locationName': 'São Paulo, SP',
      'distanceKm': 3.1,
      'condition': 'usado',
      'acquiredAt': DateTime.now().subtract(const Duration(days: 240)).toIso8601String(),
      'estimatedValue': 1000.0,
      'createdAt': now,
    });

    await db.insert('items', {
      'userId': 2,
      'title': 'Kit de utensílios de cozinha',
      'description': 'Kit completo de utensílios, pouco uso.',
      'category': 'Outros',
      'type': 'doacao',
      'photoPath': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&q=80',
      'status': 'ativo',
      'locationName': 'São Paulo, SP',
      'distanceKm': 1.8,
      'condition': 'semi_novo',
      'acquiredAt': DateTime.now().subtract(const Duration(days: 25)).toIso8601String(),
      'estimatedValue': 90.0,
      'createdAt': now,
    });

    await db.insert('items', {
      'userId': 3,
      'title': 'Fones de ouvido bluetooth',
      'description': 'Fone bluetooth com cancelamento de ruído.',
      'category': 'Eletrônicos',
      'type': 'troca',
      'photoPath': 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80',
      'status': 'ativo',
      'locationName': 'São Paulo, SP',
      'distanceKm': 4.2,
      'condition': 'semi_novo',
      'acquiredAt': DateTime.now().subtract(const Duration(days: 45)).toIso8601String(),
      'estimatedValue': 250.0,
      'createdAt': now,
    });

    await db.insert('conversations', {
      'userId1': 2,
      'userId2': 1,
      'lastMessage': 'Oi! Ainda tem a jaqueta disponível?',
      'lastMessageAt': now,
      'unreadCount': 2,
      'itemId': 1,
      'itemTitle': 'Jaqueta de couro vintage',
    });

    await db.insert('conversations', {
      'userId1': 1,
      'userId2': 2,
      'lastMessage': 'Posso trocar por uma cadeira, te interessa?',
      'lastMessageAt':
          DateTime.now().subtract(const Duration(hours: 2)).toIso8601String(),
      'unreadCount': 0,
      'itemId': 3,
      'itemTitle': 'Livros de ficção',
    });

    await db.insert('conversations', {
      'userId1': 3,
      'userId2': 1,
      'lastMessage': 'Obrigada! Vou buscar amanhã 🙂',
      'lastMessageAt':
          DateTime.now().subtract(const Duration(days: 1)).toIso8601String(),
      'unreadCount': 0,
      'itemId': 1,
      'itemTitle': 'Jaqueta de couro vintage',
    });
    await _seedDemoMessages(db);
  }

  // ---- USERS ----

  Future<int> insertUser(User user) async {
    final db = await database;
    return await db.insert('users', user.toMap());
  }

  Future<User?> getUserByEmail(String email) async {
    final db = await database;
    final maps =
        await db.query('users', where: 'email = ?', whereArgs: [email]);
    if (maps.isEmpty) return null;
    return User.fromMap(maps.first);
  }

  Future<User?> getUserById(int id) async {
    final db = await database;
    final maps = await db.query('users', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return User.fromMap(maps.first);
  }

  /// FIX 2: Compara o hash da senha informada com o hash armazenado.
  Future<User?> login(String email, String plainPassword) async {
    final db = await database;
    final hashed = User.hashPassword(plainPassword);
    final maps = await db.query(
      'users',
      where: 'email = ? AND password = ?',
      whereArgs: [email, hashed],
    );
    if (maps.isEmpty) return null;
    return User.fromMap(maps.first);
  }

  Future<int> updateUser(User user) async {
    final db = await database;
    return await db.update(
      'users',
      user.toMap(),
      where: 'id = ?',
      whereArgs: [user.id],
    );
  }

  // ---- ITEMS ----

  Future<int> insertItem(Item item) async {
    final db = await database;
    await db.rawUpdate(
      'UPDATE users SET sharedCount = sharedCount + 1 WHERE id = ?',
      [item.userId],
    );
    return await db.insert('items', item.toMap());
  }

  /// FIX 1: Nenhum valor vindo do usuário é interpolado na string SQL.
  /// Todos os filtros dinâmicos usam placeholders ? com whereArgs.
  ///
  /// MELHORIA: Suporte a paginação com [limit] e [offset].
  Future<List<Item>> getAllItems({
    String? category,
    String? type,
    int limit = 30,
    int offset = 0,
  }) async {
    final db = await database;

    // Monta a cláusula WHERE apenas com valores fixos ou placeholders.
    final whereParts = <String>["i.status = 'ativo'"];
    final args = <dynamic>[];

    if (category != null && category != 'Todos') {
      whereParts.add('i.category = ?');
      args.add(category);
    }
    if (type != null) {
      whereParts.add('i.type = ?');
      args.add(type);
    }

    // LIMIT e OFFSET também via placeholder para ser seguro.
    args.add(limit);
    args.add(offset);

    final where = whereParts.join(' AND ');

    final maps = await db.rawQuery(
      '''
      SELECT i.*, u.name AS userName
      FROM items i
      LEFT JOIN users u ON i.userId = u.id
      WHERE $where
      ORDER BY i.createdAt DESC
      LIMIT ? OFFSET ?
      ''',
      args,
    );

    return maps.map((m) => Item.fromMap(m)).toList();
  }

  Future<List<Item>> getUserItems(int userId) async {
    final db = await database;
    final maps = await db.rawQuery(
      '''
      SELECT i.*, u.name AS userName
      FROM items i
      LEFT JOIN users u ON i.userId = u.id
      WHERE i.userId = ?
      ORDER BY i.createdAt DESC
      ''',
      [userId],
    );
    return maps.map((m) => Item.fromMap(m)).toList();
  }

  Future<int> updateItemStatus(int itemId, String status) async {
    final db = await database;
    return await db.update(
      'items',
      {'status': status},
      where: 'id = ?',
      whereArgs: [itemId],
    );
  }

  Future<int> deleteItem(int itemId) async {
    final db = await database;
    return await db.delete('items', where: 'id = ?', whereArgs: [itemId]);
  }

  // ---- SAVED ITEMS ----

  Future<bool> isItemSaved(int userId, int itemId) async {
    final db = await database;
    final maps = await db.query(
      'saved_items',
      where: 'userId = ? AND itemId = ?',
      whereArgs: [userId, itemId],
    );
    return maps.isNotEmpty;
  }

  Future<void> toggleSaveItem(int userId, int itemId) async {
    final db = await database;
    final isSaved = await isItemSaved(userId, itemId);
    if (isSaved) {
      await db.delete(
        'saved_items',
        where: 'userId = ? AND itemId = ?',
        whereArgs: [userId, itemId],
      );
      await db.rawUpdate(
        'UPDATE users SET savedCount = MAX(0, savedCount - 1) WHERE id = ?',
        [userId],
      );
    } else {
      await db.insert('saved_items', {'userId': userId, 'itemId': itemId});
      await db.rawUpdate(
        'UPDATE users SET savedCount = savedCount + 1 WHERE id = ?',
        [userId],
      );
    }
  }

  Future<List<Item>> getSavedItems(int userId) async {
    final db = await database;
    final maps = await db.rawQuery(
      '''
      SELECT i.*, u.name AS userName
      FROM items i
      JOIN saved_items s ON i.id = s.itemId
      LEFT JOIN users u ON i.userId = u.id
      WHERE s.userId = ?
      ''',
      [userId],
    );
    return maps.map((m) => Item.fromMap(m)).toList();
  }

  // ---- CONVERSATIONS ----

  Future<List<Conversation>> getUserConversations(int userId) async {
    final db = await database;
    final maps = await db.rawQuery(
      '''
      SELECT c.*,
             u.name    AS otherUserName,
             u.photoPath AS otherUserPhoto
      FROM conversations c
      LEFT JOIN users u ON (
        CASE WHEN c.userId1 = ? THEN c.userId2 ELSE c.userId1 END = u.id
      )
      WHERE c.userId1 = ? OR c.userId2 = ?
      ORDER BY c.lastMessageAt DESC
      ''',
      [userId, userId, userId],
    );
    return maps.map((m) => Conversation.fromMap(m)).toList();
  }

  Future<int> createOrGetConversation(
      int userId1, int userId2, int? itemId, String? itemTitle) async {
    final db = await database;
    final existing = await db.query(
      'conversations',
      where: '(userId1 = ? AND userId2 = ?) OR (userId1 = ? AND userId2 = ?)',
      whereArgs: [userId1, userId2, userId2, userId1],
    );
    if (existing.isNotEmpty) return existing.first['id'] as int;

    return await db.insert('conversations', {
      'userId1': userId1,
      'userId2': userId2,
      'itemId': itemId,
      'itemTitle': itemTitle,
      'lastMessageAt': DateTime.now().toIso8601String(),
      'unreadCount': 0,
    });
  }

  // ---- MESSAGES ----

  Future<int> sendMessage(Message message) async {
    final db = await database;
    final id = await db.insert('messages', message.toMap());
    await db.update(
      'conversations',
      {
        'lastMessage': message.content,
        'lastMessageAt': message.sentAt.toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [message.conversationId],
    );
    return id;
  }

  Future<List<Message>> getMessages(int conversationId) async {
    final db = await database;
    final maps = await db.query(
      'messages',
      where: 'conversationId = ?',
      whereArgs: [conversationId],
      orderBy: 'sentAt ASC',
    );
    return maps.map((m) => Message.fromMap(m)).toList();
  }

  Future<void> markMessagesAsRead(int conversationId, int userId) async {
    final db = await database;
    await db.update(
      'messages',
      {'isRead': 1},
      where: 'conversationId = ? AND senderId != ?',
      whereArgs: [conversationId, userId],
    );
    await db.update(
      'conversations',
      {'unreadCount': 0},
      where: 'id = ?',
      whereArgs: [conversationId],
    );
  }
}
