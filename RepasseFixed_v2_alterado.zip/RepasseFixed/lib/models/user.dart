import 'dart:convert';
import 'package:crypto/crypto.dart';

class User {
  final int? id;
  final String name;
  final String email;
  final String password; // armazena sempre o hash SHA-256
  final String? bio;
  final String? photoPath;
  final double rating;
  final int totalRatings;
  final int sharedCount;
  final int savedCount;

  User({
    this.id,
    required this.name,
    required this.email,
    required this.password,
    this.bio,
    this.photoPath,
    this.rating = 0.0,
    this.totalRatings = 0,
    this.sharedCount = 0,
    this.savedCount = 0,
  });

  /// Retorna o hash SHA-256 de [plainText].
  static String hashPassword(String plainText) =>
      sha256.convert(utf8.encode(plainText)).toString();

  /// Cria um User já com a senha hasheada a partir de texto puro.
  factory User.withPlainPassword({
    int? id,
    required String name,
    required String email,
    required String plainPassword,
    String? bio,
    String? photoPath,
    double rating = 0.0,
    int totalRatings = 0,
    int sharedCount = 0,
    int savedCount = 0,
  }) =>
      User(
        id: id,
        name: name,
        email: email,
        password: hashPassword(plainPassword),
        bio: bio,
        photoPath: photoPath,
        rating: rating,
        totalRatings: totalRatings,
        sharedCount: sharedCount,
        savedCount: savedCount,
      );

  /// Serializa para o banco — omite 'id' quando null para não conflitar
  /// com AUTOINCREMENT.
  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'name': name,
      'email': email,
      'password': password,
      'bio': bio,
      'photoPath': photoPath,
      'rating': rating,
      'totalRatings': totalRatings,
      'sharedCount': sharedCount,
      'savedCount': savedCount,
    };
    if (id != null) map['id'] = id;
    return map;
  }

  factory User.fromMap(Map<String, dynamic> map) => User(
        id: map['id'] as int?,
        name: map['name'] as String,
        email: map['email'] as String,
        password: map['password'] as String,
        bio: map['bio'] as String?,
        photoPath: map['photoPath'] as String?,
        rating: (map['rating'] as num?)?.toDouble() ?? 0.0,
        totalRatings: map['totalRatings'] as int? ?? 0,
        sharedCount: map['sharedCount'] as int? ?? 0,
        savedCount: map['savedCount'] as int? ?? 0,
      );

  User copyWith({
    int? id,
    String? name,
    String? email,
    String? password,
    String? bio,
    String? photoPath,
    double? rating,
    int? totalRatings,
    int? sharedCount,
    int? savedCount,
  }) =>
      User(
        id: id ?? this.id,
        name: name ?? this.name,
        email: email ?? this.email,
        password: password ?? this.password,
        bio: bio ?? this.bio,
        photoPath: photoPath ?? this.photoPath,
        rating: rating ?? this.rating,
        totalRatings: totalRatings ?? this.totalRatings,
        sharedCount: sharedCount ?? this.sharedCount,
        savedCount: savedCount ?? this.savedCount,
      );
}
