class Item {
  final int? id;
  final int userId;
  final String title;
  final String description;
  final String category;
  final String type; // 'doacao' ou 'troca'
  final String? photoPath;
  final String status; // 'ativo', 'inativo', 'concluido'
  final double? latitude;
  final double? longitude;
  final String? locationName;
  final double distanceKm;
  final DateTime createdAt;
  final String? userName;
  final String condition; // 'novo', 'semi_novo' ou 'usado'
  final DateTime? acquiredAt;
  final double? estimatedValue;

  Item({
    this.id,
    required this.userId,
    required this.title,
    required this.description,
    required this.category,
    required this.type,
    this.photoPath,
    this.status = 'ativo',
    this.latitude,
    this.longitude,
    this.locationName,
    this.distanceKm = 0.0,
    DateTime? createdAt,
    this.userName,
    this.condition = 'semi_novo',
    this.acquiredAt,
    this.estimatedValue,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'userId': userId,
      'title': title,
      'description': description,
      'category': category,
      'type': type,
      'photoPath': photoPath,
      'status': status,
      'latitude': latitude,
      'longitude': longitude,
      'locationName': locationName,
      'distanceKm': distanceKm,
      'createdAt': createdAt.toIso8601String(),
      'condition': condition,
      'acquiredAt': acquiredAt?.toIso8601String(),
      'estimatedValue': estimatedValue,
    };
    if (id != null) map['id'] = id;
    return map;
  }

  factory Item.fromMap(Map<String, dynamic> map) => Item(
        id: map['id'] as int?,
        userId: map['userId'] as int,
        title: map['title'] as String,
        description: map['description'] as String,
        category: map['category'] as String,
        type: map['type'] as String,
        photoPath: map['photoPath'] as String?,
        status: map['status'] as String? ?? 'ativo',
        latitude: (map['latitude'] as num?)?.toDouble(),
        longitude: (map['longitude'] as num?)?.toDouble(),
        locationName: map['locationName'] as String?,
        distanceKm: (map['distanceKm'] as num?)?.toDouble() ?? 0.0,
        createdAt: DateTime.parse(map['createdAt'] as String),
        userName: map['userName'] as String?,
        condition: map['condition'] as String? ?? 'semi_novo',
        acquiredAt: map['acquiredAt'] == null
            ? null
            : DateTime.tryParse(map['acquiredAt'] as String),
        estimatedValue: (map['estimatedValue'] as num?)?.toDouble(),
      );
}
