class Conversation {
  final int? id;
  final int userId1;
  final int userId2;
  final String? lastMessage;
  final DateTime? lastMessageAt;
  final int unreadCount;
  final String? otherUserName;
  final String? otherUserPhoto;
  final int? itemId;
  final String? itemTitle;

  Conversation({
    this.id,
    required this.userId1,
    required this.userId2,
    this.lastMessage,
    this.lastMessageAt,
    this.unreadCount = 0,
    this.otherUserName,
    this.otherUserPhoto,
    this.itemId,
    this.itemTitle,
  });

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'userId1': userId1,
      'userId2': userId2,
      'lastMessage': lastMessage,
      'lastMessageAt': lastMessageAt?.toIso8601String(),
      'unreadCount': unreadCount,
      'itemId': itemId,
      'itemTitle': itemTitle,
    };
    if (id != null) map['id'] = id;
    return map;
  }

  factory Conversation.fromMap(Map<String, dynamic> map) => Conversation(
        id: map['id'] as int?,
        userId1: map['userId1'] as int,
        userId2: map['userId2'] as int,
        lastMessage: map['lastMessage'] as String?,
        lastMessageAt: map['lastMessageAt'] != null
            ? DateTime.parse(map['lastMessageAt'] as String)
            : null,
        unreadCount: map['unreadCount'] as int? ?? 0,
        otherUserName: map['otherUserName'] as String?,
        otherUserPhoto: map['otherUserPhoto'] as String?,
        itemId: map['itemId'] as int?,
        itemTitle: map['itemTitle'] as String?,
      );
}

class Message {
  final int? id;
  final int conversationId;
  final int senderId;
  final String content;
  final DateTime sentAt;
  final bool isRead;

  Message({
    this.id,
    required this.conversationId,
    required this.senderId,
    required this.content,
    DateTime? sentAt,
    this.isRead = false,
  }) : sentAt = sentAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'conversationId': conversationId,
      'senderId': senderId,
      'content': content,
      'sentAt': sentAt.toIso8601String(),
      'isRead': isRead ? 1 : 0,
    };
    if (id != null) map['id'] = id;
    return map;
  }

  factory Message.fromMap(Map<String, dynamic> map) => Message(
        id: map['id'] as int?,
        conversationId: map['conversationId'] as int,
        senderId: map['senderId'] as int,
        content: map['content'] as String,
        sentAt: DateTime.parse(map['sentAt'] as String),
        isRead: map['isRead'] == 1,
      );
}
