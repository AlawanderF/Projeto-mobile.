import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../database/database_helper.dart';
import '../models/item.dart';

class AddItemScreen extends StatefulWidget {
  final int userId;
  const AddItemScreen({super.key, required this.userId});

  @override
  State<AddItemScreen> createState() => _AddItemScreenState();
}

class _AddItemScreenState extends State<AddItemScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _valueCtrl = TextEditingController();
  String _category = 'Roupas';
  String _type = 'doacao';
  String _condition = 'semi_novo';
  DateTime _acquiredAt = DateTime.now().subtract(const Duration(days: 30));
  String? _photoPath;
  bool _loading = false;

  final List<String> _categories = [
    'Roupas',
    'Móveis',
    'Livros',
    'Eletrônicos',
    'Esportes',
    'Outros',
  ];

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _valueCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked =
        await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked != null && mounted) {
      setState(() => _photoPath = picked.path);
    }
  }

  Future<void> _pickAcquiredDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _acquiredAt,
      firstDate: DateTime(2010),
      lastDate: DateTime.now(),
    );
    if (picked != null && mounted) setState(() => _acquiredAt = picked);
  }

  String get _conditionLabel {
    switch (_condition) {
      case 'novo':
        return 'Novo';
      case 'usado':
        return 'Usado';
      default:
        return 'Semi-novo';
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);

    final item = Item(
      userId: widget.userId,
      title: _titleCtrl.text.trim(),
      description: _descCtrl.text.trim(),
      category: _category,
      type: _type,
      photoPath: _photoPath,
      condition: _condition,
      acquiredAt: _condition == 'novo' ? null : _acquiredAt,
      estimatedValue: double.tryParse(_valueCtrl.text.replaceAll(',', '.')),
      locationName: 'São Paulo, SP',
      distanceKm: (0.5 + (DateTime.now().millisecond % 40) / 10),
    );

    await DatabaseHelper.instance.insertItem(item);

    if (!mounted) return;
    setState(() => _loading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Item publicado com sucesso!'),
        backgroundColor: Colors.green,
      ),
    );
    Navigator.pop(context, true);
  }

  Widget _buildConditionChip(String value, String label) {
    final selected = _condition == value;
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      selectedColor: const Color(0xFF00A86B).withOpacity(0.16),
      onSelected: (_) {
        setState(() {
          _condition = value;
          if (value == 'novo') {
            _acquiredAt = DateTime.now();
          } else if (value == 'semi_novo') {
            _acquiredAt = DateTime.now().subtract(const Duration(days: 30));
          } else {
            _acquiredAt = DateTime.now().subtract(const Duration(days: 180));
          }
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF00A86B), Color(0xFF00BCD4)],
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Text(
                      'Adicionar Item',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Foto do item',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 15)),
                    const SizedBox(height: 8),
                    GestureDetector(
                      onTap: _pickImage,
                      child: Container(
                        height: 180,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: Colors.grey.shade300,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(12),
                          color: Colors.grey.shade50,
                        ),
                        child: _photoPath != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.file(
                                  File(_photoPath!),
                                  fit: BoxFit.cover,
                                ),
                              )
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.upload,
                                      size: 40, color: Colors.grey.shade400),
                                  const SizedBox(height: 8),
                                  Text(
                                    'Clique para adicionar foto',
                                    style:
                                        TextStyle(color: Colors.grey.shade500),
                                  ),
                                ],
                              ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text('Título',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 15)),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _titleCtrl,
                      decoration: const InputDecoration(
                        hintText: 'Ex: Jaqueta de couro vintage',
                      ),
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Informe o título' : null,
                    ),
                    const SizedBox(height: 20),
                    const Text('Descrição',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 15)),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _descCtrl,
                      maxLines: 4,
                      decoration: const InputDecoration(
                        hintText:
                            'Descreva o item, seu estado, tamanho, etc...',
                      ),
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Informe a descrição' : null,
                    ),
                    const SizedBox(height: 20),
                    const Text('Categoria',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 15)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: _categories.map((cat) {
                        final sel = cat == _category;
                        return GestureDetector(
                          onTap: () => setState(() => _category = cat),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              color: sel
                                  ? const Color(0xFF00A86B).withOpacity(0.1)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: sel
                                    ? const Color(0xFF00A86B)
                                    : Colors.grey.shade300,
                              ),
                            ),
                            child: Text(
                              cat,
                              style: TextStyle(
                                color: sel
                                    ? const Color(0xFF00A86B)
                                    : Colors.grey.shade700,
                                fontWeight:
                                    sel ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 20),
                    const Text('Tipo',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 15)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () => setState(() => _type = 'doacao'),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              decoration: BoxDecoration(
                                gradient: _type == 'doacao'
                                    ? const LinearGradient(colors: [
                                        Color(0xFF00A86B),
                                        Color(0xFF00BCD4)
                                      ])
                                    : null,
                                color: _type != 'doacao'
                                    ? Colors.grey.shade100
                                    : null,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: _type == 'doacao'
                                      ? Colors.transparent
                                      : Colors.grey.shade300,
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.card_giftcard,
                                      color: _type == 'doacao'
                                          ? Colors.white
                                          : Colors.grey,
                                      size: 18),
                                  const SizedBox(width: 6),
                                  Text(
                                    'Doação',
                                    style: TextStyle(
                                      color: _type == 'doacao'
                                          ? Colors.white
                                          : Colors.grey,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: GestureDetector(
                            onTap: () => setState(() => _type = 'troca'),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              decoration: BoxDecoration(
                                gradient: _type == 'troca'
                                    ? const LinearGradient(colors: [
                                        Color(0xFF00A86B),
                                        Color(0xFF00BCD4)
                                      ])
                                    : null,
                                color: _type != 'troca'
                                    ? Colors.grey.shade100
                                    : null,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: _type == 'troca'
                                      ? Colors.transparent
                                      : Colors.grey.shade300,
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.repeat,
                                      color: _type == 'troca'
                                          ? Colors.white
                                          : Colors.grey,
                                      size: 18),
                                  const SizedBox(width: 6),
                                  Text(
                                    'Troca',
                                    style: TextStyle(
                                      color: _type == 'troca'
                                          ? Colors.white
                                          : Colors.grey,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Text('Estado do item',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 15)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        _buildConditionChip('novo', 'Novo'),
                        _buildConditionChip('semi_novo', 'Semi-novo'),
                        _buildConditionChip('usado', 'Usado'),
                      ],
                    ),
                    if (_condition != 'novo') ...[
                      const SizedBox(height: 16),
                      const Text('Quando adquiriu o produto?',
                          style: TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 15)),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: _pickAcquiredDate,
                        icon: const Icon(Icons.calendar_today_outlined),
                        label: Text(
                          '${_acquiredAt.day.toString().padLeft(2, '0')}/${_acquiredAt.month.toString().padLeft(2, '0')}/${_acquiredAt.year}',
                        ),
                      ),
                    ],
                    const SizedBox(height: 16),
                    const Text('Valor aproximado do item',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 15)),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _valueCtrl,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        prefixText: 'R\$ ',
                        hintText: 'Ex: 120,00',
                      ),
                    ),
                    const SizedBox(height: 28),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _loading ? null : _submit,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          backgroundColor: const Color(0xFF00A86B),
                        ),
                        child: _loading
                            ? const CircularProgressIndicator(
                                color: Colors.white)
                            : const Text(
                                'Publicar item',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
