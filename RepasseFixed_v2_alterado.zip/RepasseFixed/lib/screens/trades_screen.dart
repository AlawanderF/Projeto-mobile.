import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/item.dart';
import '../widgets/item_card.dart';

class TradesScreen extends StatefulWidget {
  final int userId;
  const TradesScreen({super.key, required this.userId});

  @override
  State<TradesScreen> createState() => _TradesScreenState();
}

class _TradesScreenState extends State<TradesScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  List<Item> _myItems = [];
  List<Item> _savedItems = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() => _loading = true);

    // FIX 4: usa widget.userId diretamente — sem getter intermediário
    // que podia ser chamado antes de widget estar disponível.
    final my = await DatabaseHelper.instance.getUserItems(widget.userId);
    final saved = await DatabaseHelper.instance.getSavedItems(widget.userId);

    if (!mounted) return;
    setState(() {
      _myItems = my;
      _savedItems = saved;
      _loading = false;
    });
  }

  Future<void> _changeStatus(Item item) async {
    final newStatus = item.status == 'ativo' ? 'inativo' : 'ativo';
    await DatabaseHelper.instance.updateItemStatus(item.id!, newStatus);
    _load();
  }

  Future<void> _deleteItem(Item item) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Excluir item'),
        content: Text('Deseja excluir "${item.title}"?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child:
                  const Text('Excluir', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (confirm == true) {
      await DatabaseHelper.instance.deleteItem(item.id!);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF00A86B), Color(0xFF00BCD4)],
            ),
          ),
        ),
        title: const Text(
          'Minhas Trocas',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(text: 'Meus itens'),
            Tab(text: 'Salvos'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabCtrl,
              children: [
                // Meus itens
                _myItems.isEmpty
                    ? const Center(child: Text('Você ainda não publicou itens'))
                    : ListView.builder(
                        padding: const EdgeInsets.all(12),
                        itemCount: _myItems.length,
                        itemBuilder: (_, i) {
                          final item = _myItems[i];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            child: ListTile(
                              leading: Container(
                                width: 56,
                                height: 56,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(Icons.image_outlined,
                                    color: Colors.grey),
                              ),
                              title: Text(item.title,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w600)),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 4),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: item.status == 'ativo'
                                          ? Colors.green.shade100
                                          : Colors.grey.shade200,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Text(
                                      item.status == 'ativo'
                                          ? 'Ativo'
                                          : 'Inativo',
                                      style: TextStyle(
                                        color: item.status == 'ativo'
                                            ? Colors.green.shade700
                                            : Colors.grey,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              trailing: PopupMenuButton(
                                itemBuilder: (_) => [
                                  PopupMenuItem(
                                    onTap: () => _changeStatus(item),
                                    child: Text(item.status == 'ativo'
                                        ? 'Desativar'
                                        : 'Ativar'),
                                  ),
                                  PopupMenuItem(
                                    onTap: () => _deleteItem(item),
                                    child: const Text('Excluir',
                                        style: TextStyle(color: Colors.red)),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),

                // Salvos
                _savedItems.isEmpty
                    ? const Center(child: Text('Nenhum item salvo ainda'))
                    : GridView.builder(
                        padding: const EdgeInsets.all(12),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 0.78,
                        ),
                        itemCount: _savedItems.length,
                        itemBuilder: (_, i) => ItemCard(
                          item: _savedItems[i],
                          currentUserId: widget.userId,
                          onSave: _load,
                        ),
                      ),
              ],
            ),
    );
  }
}
