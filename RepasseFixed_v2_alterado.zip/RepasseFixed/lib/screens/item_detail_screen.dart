import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/item.dart';

class ItemDetailScreen extends StatefulWidget {
  final Item item;

  const ItemDetailScreen({super.key, required this.item});

  @override
  State<ItemDetailScreen> createState() => _ItemDetailScreenState();
}

class _ItemDetailScreenState extends State<ItemDetailScreen> {
  final _otherValueCtrl = TextEditingController();
  double? _otherValue;

  @override
  void dispose() {
    _otherValueCtrl.dispose();
    super.dispose();
  }

  bool get _isNetworkImage {
    final p = widget.item.photoPath;
    return p != null && (p.startsWith('http://') || p.startsWith('https://'));
  }

  Widget _buildImage() {
    final path = widget.item.photoPath;
    if (path == null || path.isEmpty) return _placeholder;
    if (_isNetworkImage) {
      return CachedNetworkImage(
        imageUrl: path,
        fit: BoxFit.cover,
        placeholder: (_, __) => const Center(child: CircularProgressIndicator()),
        errorWidget: (_, __, ___) => _placeholder,
      );
    }
    return Image.file(File(path), fit: BoxFit.cover, errorBuilder: (_, __, ___) => _placeholder);
  }

  static const Widget _placeholder = ColoredBox(
    color: Color(0xFFEEEEEE),
    child: Center(child: Icon(Icons.image_outlined, size: 58, color: Color(0xFFBDBDBD))),
  );

  String _conditionLabel(String value) {
    switch (value) {
      case 'novo':
        return 'Novo';
      case 'usado':
        return 'Usado';
      default:
        return 'Semi-novo';
    }
  }

  DateTime? get _effectiveAcquiredAt {
    if (widget.item.condition == 'novo') return null;
    if (widget.item.acquiredAt != null) return widget.item.acquiredAt;
    if (widget.item.condition == 'semi_novo') {
      return DateTime.now().subtract(const Duration(days: 30));
    }
    return DateTime.now().subtract(const Duration(days: 180));
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Produto novo';
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    return '$day/$month/${date.year}';
  }

  int get _usageDays {
    final acquiredAt = _effectiveAcquiredAt;
    if (acquiredAt == null) return 0;
    final days = DateTime.now().difference(acquiredAt).inDays;
    if (widget.item.condition == 'semi_novo') return days < 15 ? 15 : days;
    if (widget.item.condition == 'usado') return (days * 1.4).ceil();
    return days;
  }

  String get _usageText {
    if (widget.item.condition == 'novo') return 'Sem tempo de uso';
    if (_usageDays < 30) return '$_usageDays dias de uso';
    final months = (_usageDays / 30).round();
    if (months < 12) return '$months meses de uso';
    final years = (_usageDays / 365).toStringAsFixed(1).replaceAll('.', ',');
    return '$years anos de uso';
  }

  String _money(double value) => 'R\$ ${value.toStringAsFixed(2).replaceAll('.', ',')}';

  @override
  Widget build(BuildContext context) {
    final myValue = widget.item.estimatedValue ?? 0;
    final difference = myValue - (_otherValue ?? 0);
    final canSimulate = widget.item.type == 'troca' && myValue > 0;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF00A86B),
        foregroundColor: Colors.white,
        title: const Text('Informações do produto'),
      ),
      body: ListView(
        children: [
          SizedBox(height: 250, width: double.infinity, child: _buildImage()),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _badge(widget.item.type == 'doacao' ? 'Doação' : 'Troca', widget.item.type == 'doacao' ? Icons.card_giftcard : Icons.repeat),
                    const SizedBox(width: 8),
                    _badge(_conditionLabel(widget.item.condition), Icons.verified_outlined),
                  ],
                ),
                const SizedBox(height: 14),
                Text(widget.item.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(widget.item.description, style: const TextStyle(fontSize: 15, height: 1.35)),
                const SizedBox(height: 20),
                _infoTile(Icons.history, 'Tempo de uso', _usageText),
                _infoTile(Icons.event_available_outlined, 'Adquirido em', _formatDate(_effectiveAcquiredAt)),
                _infoTile(Icons.category_outlined, 'Categoria', widget.item.category),
                _infoTile(Icons.location_on_outlined, 'Localização', widget.item.locationName ?? 'Não informado'),
                _infoTile(Icons.attach_money, 'Preço médio semelhante', myValue > 0 ? _money(myValue) : 'Não informado'),
                if (widget.item.type == 'troca') ...[
                  const SizedBox(height: 18),
                  const Text('Simulação de troca', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('Informe quanto a outra pessoa pagou no produto dela para calcular uma possível volta em dinheiro.'),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _otherValueCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Valor pago pela outra pessoa',
                      prefixText: 'R\$ ',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (value) => setState(() => _otherValue = double.tryParse(value.replaceAll(',', '.'))),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF00A86B).withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      !canSimulate || _otherValue == null
                          ? 'Informe o valor para simular uma possível volta.'
                          : difference > 0
                              ? 'A outra pessoa teria que voltar ${_money(difference)}.'
                              : difference < 0
                                  ? 'Você teria que voltar ${_money(difference.abs())}.'
                                  : 'Troca equilibrada, sem volta de dinheiro.',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _badge(String label, IconData icon) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: const Color(0xFF00A86B).withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 14, color: const Color(0xFF00A86B)),
          const SizedBox(width: 4),
          Text(label, style: const TextStyle(color: Color(0xFF00A86B), fontWeight: FontWeight.w600)),
        ]),
      );

  Widget _infoTile(IconData icon, String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, size: 21, color: const Color(0xFF00A86B)),
          const SizedBox(width: 10),
          Expanded(child: Text.rich(TextSpan(text: '$label: ', style: const TextStyle(fontWeight: FontWeight.bold), children: [TextSpan(text: value, style: const TextStyle(fontWeight: FontWeight.normal))]))),
        ]),
      );
}
