import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/item.dart';
import '../widgets/item_card.dart';
import 'add_item_screen.dart';
import 'chat_screen.dart';
import 'profile_screen.dart';
import 'trades_screen.dart';

class HomeScreen extends StatefulWidget {
  final int userId;
  const HomeScreen({super.key, required this.userId});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  int _feedKey = 0;

  // Páginas lazy: só instanciadas quando visitadas pela primeira vez
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      _FeedPage(key: ValueKey(_feedKey), userId: widget.userId),
      TradesScreen(userId: widget.userId),
      ChatScreen(userId: widget.userId),
      ProfileScreen(userId: widget.userId),
    ];
  }

  void _rebuildFeed() {
    setState(() {
      _feedKey++;
      _pages[0] = _FeedPage(key: ValueKey(_feedKey), userId: widget.userId);
    });
  }

  // Itens da BottomBar como constante — não recriam a cada build
  static const _navItems = [
    BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Home'),
    BottomNavigationBarItem(icon: Icon(Icons.repeat), label: 'Trades'),
    BottomNavigationBarItem(
        icon: Icon(Icons.add_circle_outline, size: 32), label: 'Add'),
    BottomNavigationBarItem(
        icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
    BottomNavigationBarItem(
        icon: Icon(Icons.person_outline), label: 'Perfil'),
  ];

  @override
  Widget build(BuildContext context) {
    // Ajusta índice para o IndexedStack (que não tem o botão Add)
    final stackIndex = _currentIndex > 2 ? _currentIndex - 1 : _currentIndex;

    return Scaffold(
      // IndexedStack mantém estado das abas sem recriar widgets
      body: IndexedStack(
        index: stackIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (i) async {
          if (i == 2) {
            final result = await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AddItemScreen(userId: widget.userId),
              ),
            );
            if (result == true && mounted) _rebuildFeed();
          } else {
            if (_currentIndex != i) setState(() => _currentIndex = i);
          }
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF00A86B),
        unselectedItemColor: Colors.grey,
        items: _navItems,
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class _FeedPage extends StatefulWidget {
  final int userId;
  const _FeedPage({super.key, required this.userId});

  @override
  State<_FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<_FeedPage>
    with AutomaticKeepAliveClientMixin {
  // AutomaticKeepAliveClientMixin mantém o estado da aba ao trocar de página
  @override
  bool get wantKeepAlive => true;

  String _selectedCategory = 'Todos';
  List<Item> _items = [];
  bool _loading = true;

  static const int _pageSize = 20;
  int _offset = 0;
  bool _hasMore = true;
  bool _loadingMore = false;
  late final ScrollController _scrollCtrl;

  final _searchCtrl = TextEditingController();
  String _search = '';

  // Debounce para não buscar a cada tecla digitada
  DateTime _lastSearch = DateTime.now();

  static const _categories = [
    'Todos', 'Roupas', 'Móveis', 'Livros',
    'Eletrônicos', 'Esportes', 'Outros',
  ];

  // Gradiente declarado como constante — não recria objeto a cada build
  static const _headerGradient = BoxDecoration(
    gradient: LinearGradient(
      colors: [Color(0xFF00A86B), Color(0xFF00BCD4)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
  );

  @override
  void initState() {
    super.initState();
    _scrollCtrl = ScrollController()..addListener(_onScroll);
    _loadData(reset: true);
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollCtrl.position.pixels >=
            _scrollCtrl.position.maxScrollExtent - 300 &&
        !_loadingMore &&
        _hasMore) {
      _loadMore();
    }
  }

  Future<void> _loadData({bool reset = false}) async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      if (reset) {
        _offset = 0;
        _hasMore = true;
        _items = [];
      }
    });

    final items = await DatabaseHelper.instance.getAllItems(
      category: _selectedCategory == 'Todos' ? null : _selectedCategory,
      limit: _pageSize,
      offset: 0,
    );

    if (!mounted) return;
    setState(() {
      _items = items;
      _loading = false;
      _offset = items.length;
      _hasMore = items.length == _pageSize;
    });
  }

  Future<void> _loadMore() async {
    if (!mounted) return;
    setState(() => _loadingMore = true);

    final more = await DatabaseHelper.instance.getAllItems(
      category: _selectedCategory == 'Todos' ? null : _selectedCategory,
      limit: _pageSize,
      offset: _offset,
    );

    if (!mounted) return;
    setState(() {
      _items.addAll(more);
      _offset += more.length;
      _hasMore = more.length == _pageSize;
      _loadingMore = false;
    });
  }

  void _onSearchChanged(String value) {
    // Debounce: espera 300ms sem digitar antes de atualizar
    _lastSearch = DateTime.now();
    final capturedTime = _lastSearch;
    Future.delayed(const Duration(milliseconds: 300), () {
      if (_lastSearch == capturedTime && mounted) {
        setState(() => _search = value);
      }
    });
  }

  List<Item> get _filteredItems {
    if (_search.isEmpty) return _items;
    final q = _search.toLowerCase();
    return _items
        .where((i) =>
            i.title.toLowerCase().contains(q) ||
            i.description.toLowerCase().contains(q))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // obrigatório com AutomaticKeepAliveClientMixin
    return Scaffold(
      body: Column(
        children: [
          // Header com gradiente constante
          DecoratedBox(
            decoration: _headerGradient,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Repassa',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Row(
                              children: [
                                const Icon(Icons.location_on,
                                    color: Colors.white70, size: 14),
                                const SizedBox(width: 2),
                                Text(
                                  'São Paulo, SP',
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.9),
                                      fontSize: 13),
                                ),
                              ],
                            ),
                          ],
                        ),
                        PopupMenuButton<String>(
                          icon: const Icon(Icons.tune, color: Colors.white),
                          onSelected: (value) {
                            if (value == 'refresh') {
                              _loadData(reset: true);
                            } else if (value == 'only_trades') {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Use a categoria Trocas na barra inferior para ver seus itens de troca.'),
                                ),
                              );
                            } else if (value == 'clear_search') {
                              _searchCtrl.clear();
                              setState(() => _search = '');
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(
                              value: 'refresh',
                              child: Text('Atualizar lista'),
                            ),
                            PopupMenuItem(
                              value: 'clear_search',
                              child: Text('Limpar busca'),
                            ),
                            PopupMenuItem(
                              value: 'only_trades',
                              child: Text('Opções de troca'),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _searchCtrl,
                      onChanged: _onSearchChanged,
                      decoration: InputDecoration(
                        hintText: 'Buscar itens...',
                        prefixIcon:
                            const Icon(Icons.search, color: Colors.grey),
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 20),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Categorias
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: _categories.length,
              // itemExtent fixo ajuda o Flutter a calcular layout sem medir
              itemBuilder: (_, i) {
                final cat = _categories[i];
                final selected = cat == _selectedCategory;
                return GestureDetector(
                  onTap: () {
                    if (_selectedCategory == cat) return; // evita rebuild desnecessário
                    setState(() => _selectedCategory = cat);
                    _loadData(reset: true);
                  },
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: selected
                          ? const Color(0xFF00A86B)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: selected
                            ? const Color(0xFF00A86B)
                            : Colors.grey.shade300,
                      ),
                    ),
                    child: Text(
                      cat,
                      style: TextStyle(
                        color:
                            selected ? Colors.white : Colors.grey.shade700,
                        fontWeight: selected
                            ? FontWeight.bold
                            : FontWeight.normal,
                        fontSize: 13,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // Grid com paginação
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _filteredItems.isEmpty
                    ? const Center(child: Text('Nenhum item encontrado'))
                    : RefreshIndicator(
                        onRefresh: () => _loadData(reset: true),
                        child: GridView.builder(
                          controller: _scrollCtrl,
                          padding: const EdgeInsets.all(12),
                          // addRepaintBoundaries: cada card tem seu próprio
                          // boundary de repintura — não repinta o grid inteiro
                          addRepaintBoundaries: true,
                          // addAutomaticKeepAlives: false economiza memória;
                          // cards fora da tela são descartados do heap
                          addAutomaticKeepAlives: false,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            childAspectRatio: 0.78,
                          ),
                          itemCount: _filteredItems.length +
                              (_loadingMore ? 1 : 0),
                          itemBuilder: (_, i) {
                            if (i == _filteredItems.length) {
                              return const Center(
                                child: Padding(
                                  padding: EdgeInsets.all(16),
                                  child: CircularProgressIndicator(),
                                ),
                              );
                            }
                            return ItemCard(
                              key: ValueKey(_filteredItems[i].id),
                              item: _filteredItems[i],
                              currentUserId: widget.userId,
                              onSave: () => _loadData(reset: true),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}
